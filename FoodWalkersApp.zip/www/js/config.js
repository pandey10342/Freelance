var krms_config ={				
	'ApiUrl':"http://foodwalkers.biz/mobileappv2/api",	
	'AppTitle':"Food Walkers",
	'ApiKey' : 'walkwithfood',	
	'debug': false
};