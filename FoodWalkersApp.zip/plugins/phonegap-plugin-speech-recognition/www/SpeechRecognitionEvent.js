var SpeechRecognitionEvent = function() {
    this.resultIndex;
    this.results;
    this.interpretation;
    this.emma;
};

module.exports = SpeechRecognitionEvent;
